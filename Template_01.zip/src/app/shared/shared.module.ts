import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from './layout/layout.component';
import { LoginComponent } from './login/login.component';
import {MatButtonModule} from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { MatToolbarModule } from '@angular/material/toolbar';
import { BlogCardComponent } from './blog-card/blog-card.component';
import { ButtonModule } from 'primeng/button';
import { TooltipModule } from 'primeng/tooltip';
import { ListboxModule } from 'primeng/listbox';
import { MenuModule } from 'primeng/menu';
import { InputTextModule } from 'primeng/inputtext';
import { PostEditorComponent } from './post-editor/post-editor.component';
import { EditorModule } from 'primeng/editor';

@NgModule({
  declarations: [
    LayoutComponent,    
    LoginComponent, 
    BlogCardComponent, PostEditorComponent   
  ],
  imports: [
    CommonModule,
    FormsModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatCardModule,   
    MatButtonModule,
    MatToolbarModule,
    ButtonModule,
    TooltipModule,
    ListboxModule,
    MenuModule,
    InputTextModule,
    EditorModule
  ],
  providers: [FormsModule,ReactiveFormsModule],
  exports:[LoginComponent, LayoutComponent,BlogCardComponent,PostEditorComponent]
})
export class SharedModule { }
