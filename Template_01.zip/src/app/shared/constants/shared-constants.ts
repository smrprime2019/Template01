export const SharedConstants={


    
}