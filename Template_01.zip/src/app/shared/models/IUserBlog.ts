export interface IUserBlog{
    Id?:string,
    Title?:string,
    Description?:string,
    ImageUrl?: string
}