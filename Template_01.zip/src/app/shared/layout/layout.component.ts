import { Component, OnInit } from '@angular/core';
import { IUserBlog } from '../models/IUserBlog';
import { MenuItem } from 'primeng/api';
import { Router } from '@angular/router';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

  items: MenuItem[]=[];

  logoutMenu: MenuItem[]=[];

    ngOnInit() {
        this.items = [
            {
                label: 'Posts',
                icon: 'pi pi-fw pi-book',
            },
            {
                label: 'Comments',
                icon: 'pi pi-fw pi-comment'
            },
            {
              label: 'Settings',
              icon: 'pi pi-fw pi-cog'
          }
        ];

        this.logoutMenu = [
          {
              label: 'Profile',
              icon: 'pi pi-fw pi-user-edit',
          },
          {
              label: 'Sign out',
              icon: 'pi pi-fw pi-sign-out'
          }
      ];
    }
    blogList:IUserBlog[]=[{
      Description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lo",Id:"12312 23123",Title:"First Blog"
    },
    {
      Description:"Lorem Ipsum is simply dummy text of the printing and ",Id:"12312 23123",Title:"Second Blog"
    }];

  constructor(private route:Router) { }

  isSidebarHidden = false;

  toggleSidebar(): void {
    this.isSidebarHidden = !this.isSidebarHidden;   
  }

  NavigateToEditor():void{
    this.route.navigate(["PostEditor"])
  }

}
