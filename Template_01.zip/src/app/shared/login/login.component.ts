import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm:any;
  constructor(private route:Router) { }


  ngOnInit(): void {
    
  }

  onSubmit(){
    this.route.navigate(["Layout"])
  }

}
