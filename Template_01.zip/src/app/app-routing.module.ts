import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './shared/login/login.component';
import { LayoutComponent } from './shared/layout/layout.component';
import { PostEditorComponent } from './shared/post-editor/post-editor.component';

const routes: Routes = [ {
  path: '',
  component: LoginComponent  
},
{
  path: 'Layout',
  component: LayoutComponent  
},
{
  path: 'PostEditor',
  component: PostEditorComponent  
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
